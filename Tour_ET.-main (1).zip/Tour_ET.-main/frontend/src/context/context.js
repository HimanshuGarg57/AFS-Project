import { createContext } from "react";
export const context = createContext();
export const roomId = createContext();
